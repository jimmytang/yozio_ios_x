//
//  NSString+MD5.h
//  Yozio
//
//  Created by Jimmy Tang on 6/8/12.
//  Copyright (c) 2012 University of California at Berkeley. All rights reserved.
//

#if !defined(__NSString_MD5__)
#define __NSString_MD5__ 1

@interface NSString (MD5)

- (NSString *)MD5String;

@end

#endif /* ! __NSString_MD5__ */
