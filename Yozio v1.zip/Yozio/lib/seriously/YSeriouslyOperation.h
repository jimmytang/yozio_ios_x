//
//  SeriouslyOperation.h
//  Prototype
//
//  Created by Corey Johnson on 6/18/10.
//  Copyright 2010 Probably Interactive. All rights reserved.
//

#if !defined(__YSeriouslyOperation__)
#define __YSeriouslyOperation__ 1

#import <Foundation/Foundation.h>
#import "YSeriouslyConstants.h"

@interface YSeriouslyOperation : NSOperation {
    NSURLConnection *_connection;
    SeriouslyHandler _handler;
    SeriouslyProgressHandler _progressHandler;
    NSMutableData *_data;
    NSHTTPURLResponse *_response;
    NSError *_error;
    
    NSURLRequest *_urlRequest;
    
    BOOL _isFinished;
    BOOL _isExecuting;
    BOOL _isCanceled;    
}

@property () BOOL isFinished;
@property () BOOL isExecuting;
@property () BOOL isCanceled;

+ (id)operationWithRequest:(NSURLRequest *)urlRequest handler:(SeriouslyHandler)handler progressHandler:(SeriouslyProgressHandler)progressHandler;

@end

#endif /* ! __YSeriouslyOperation__ */
